import os
import threading
from pathlib import Path
import time
import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox
import queue

# --- CONFIGURATION ---
# This dictionary maps folder names to the file extensions they should contain.
# You can easily customize this to your needs by adding new categories or file types.
FILE_TYPE_MAPPINGS = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".heic", ".tiff"],
    "Documents": [".pdf", ".docx", ".doc", ".txt", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".rtf"],
    "Audio": [".mp3", ".wav", ".aac", ".flac", ".ogg", ".m4a"],
    "Video": [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
    "Code": [".py", ".js", ".html", ".css", ".java", ".cpp", ".cs", ".go", ".json", ".xml"],
    "Executables": [".exe", ".msi", ".dmg", ".app", ".deb"],
    "Other": []  # A fallback folder for any file types not listed above.
}
# --- END OF CONFIGURATION ---


class FileOrganizerApp:
    """
    A GUI application for organizing files in a user-selected directory.
    This version includes enhanced diagnostics.
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Intelligent File Organizer (Diagnostic Mode)")
        self.root.geometry("650x500")
        self.root.minsize(500, 400)

        self.target_directory = tk.StringVar()
        self.log_queue = queue.Queue()

        main_frame = tk.Frame(root, padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        selection_frame = tk.Frame(main_frame)
        selection_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Label(selection_frame, text="Target Folder:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.dir_entry = tk.Entry(selection_frame, textvariable=self.target_directory, state='readonly')
        self.dir_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.browse_button = tk.Button(selection_frame, text="Browse...", command=self.select_directory)
        self.browse_button.pack(side=tk.LEFT, padx=(5, 0))

        log_frame = tk.Frame(main_frame)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_area = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, state='disabled', bg="#f0f0f0", font=("Consolas", 9))
        self.log_area.pack(fill=tk.BOTH, expand=True)

        self.organize_button = tk.Button(main_frame, text="Organize Files", command=self.start_organization_thread, state='disabled')
        self.organize_button.pack(pady=(10, 0), fill=tk.X)
        
        self.process_queue()

    def select_directory(self):
        directory_path = filedialog.askdirectory(title="Select a folder to organize")
        if directory_path:
            self.target_directory.set(directory_path)
            self.organize_button.config(state='normal')
            self.clear_logs()
            self.log_message(f"Selected directory: {directory_path}\nReady to organize.")

    def log_message(self, message):
        self.log_area.config(state='normal')
        self.log_area.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {message}\n")
        self.log_area.config(state='disabled')
        self.log_area.see(tk.END)
    
    def clear_logs(self):
        self.log_area.config(state='normal')
        self.log_area.delete('1.0', tk.END)
        self.log_area.config(state='disabled')

    def process_queue(self):
        try:
            message = self.log_queue.get_nowait()
            if isinstance(message, str):
                if message == "__DONE__":
                    self.log_message("Received completion signal. Resetting UI.")
                    self.reset_ui()
                    messagebox.showinfo("Process Finished", "The organization process has finished. Please check the log for details.")
                else:
                    self.log_message(message)
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_queue)

    def start_organization_thread(self):
        self.clear_logs()
        self.organize_button.config(state='disabled')
        self.browse_button.config(state='disabled')
        
        thread = threading.Thread(target=self.run_organization, daemon=True)
        thread.start()

    def run_organization(self):
        # This is the "catch-all" handler. It will catch any error, no matter how severe.
        try:
            self.log_queue.put("Worker thread started.")
            directory_str = self.target_directory.get()
            if not directory_str:
                self.log_queue.put("Error: No directory selected.")
                return

            directory = Path(directory_str)
            
            self.log_queue.put("Checking permissions...")
            if not os.access(directory, os.R_OK):
                self.log_queue.put(f"FATAL: No 'read' permission for '{directory}'.")
                self.log_queue.put("On macOS or Windows, you may need to grant this app permissions in System Settings or Windows Security.")
                return
            if not os.access(directory, os.W_OK):
                self.log_queue.put(f"FATAL: No 'write' permission for '{directory}'.")
                self.log_queue.put("Organization cancelled. Check Controlled Folder Access on Windows or system permissions.")
                return
            self.log_queue.put("Permissions check passed.")

            self.log_queue.put(f"Listing items in: {directory}")
            items = list(directory.iterdir())
            self.log_queue.put(f"Found {len(items)} total items (files and folders).")

            if not any(i.is_file() for i in items):
                self.log_queue.put("No files found to organize in this directory.")
            
            start_time = time.time()
            files_moved = 0
            files_skipped = 0

            extension_to_folder = {ext.lower(): folder for folder, exts in FILE_TYPE_MAPPINGS.items() for ext in exts}

            for item in items:
                if not item.is_file():
                    self.log_queue.put(f"Skipping (is a directory): {item.name}")
                    continue

                self.log_queue.put(f"Processing: {item.name}")
                dest_folder_name = extension_to_folder.get(item.suffix.lower(), "Other")
                dest_folder_path = directory / dest_folder_name
                
                try:
                    dest_folder_path.mkdir(exist_ok=True)
                    destination_file_path = dest_folder_path / item.name

                    if not destination_file_path.exists():
                        item.rename(destination_file_path)
                        self.log_queue.put(f"  -> Moved to {dest_folder_name}/")
                        files_moved += 1
                    else:
                        self.log_queue.put(f"  -> Skipped (file already exists in {dest_folder_name}/)")
                        files_skipped += 1
                except Exception as e:
                    self.log_queue.put(f"  -> ERROR moving file: {e}")

            duration = time.time() - start_time
            summary = (
                f"\n--- SCAN COMPLETE ---\n"
                f"Total files moved: {files_moved}\n"
                f"Total files skipped: {files_skipped}\n"
                f"Time taken: {duration:.2f} seconds"
            )
            self.log_queue.put(summary)
        
        except Exception as e:
            self.log_queue.put(f"\n--- A CRITICAL ERROR OCCURRED IN THE WORKER THREAD ---")
            self.log_queue.put(f"Error Type: {type(e).__name__}")
            self.log_queue.put(f"Error Details: {e}")
            self.log_queue.put("The process was stopped. Please check the folder path and OS permissions.")
        
        finally:
            self.log_queue.put("Worker thread is finishing.")
            # This signal tells the main thread to re-enable buttons and show the final popup.
            self.log_queue.put("__DONE__")

    def reset_ui(self):
        """Resets the UI buttons to their initial active state."""
        self.browse_button.config(state='normal')
        self.organize_button.config(state='normal')

if __name__ == "__main__":
    root = tk.Tk()
    app = FileOrganizerApp(root)
    root.mainloop()
