import os
from pathlib import Path
import time

# --- CONFIGURATION ---
# IMPORTANT: SPECIFY THE DIRECTORY YOU WANT TO ORGANIZE.
# For example, to organize your Desktop, you might use: Path.home() / "Desktop"
# To organize your Downloads, use: Path.home() / "Downloads"
# To organize a custom folder, use: Path("/path/to/your/folder")
TARGET_DIRECTORY = Path.home() / "Downloads"

# This dictionary maps folder names to the file extensions they should contain.
# You can easily customize this to your needs. Add new categories or file types.
FILE_TYPE_MAPPINGS = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".heic", ".tiff"],
    "Documents": [".pdf", ".docx", ".doc", ".txt", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".rtf"],
    "Audio": [".mp3", ".wav", ".aac", ".flac", ".ogg", ".m4a"],
    "Video": [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
    "Code": [".py", ".js", ".html", ".css", ".java", ".cpp", ".cs", ".go", ".json", ".xml"],
    "Executables": [".exe", ".msi", ".dmg", ".app", ".deb"],
    # A fallback folder for any file types not listed above.
    "Other": [] 
}
# --- END OF CONFIGURATION ---

def organize_files(directory: Path):
    """
    Organizes files in the specified directory into subfolders based on their extension.

    Args:
        directory (Path): The path to the directory to organize.
    """
    if not directory.is_dir():
        print(f"Error: The specified directory '{directory}' does not exist.")
        return

    print(f"Starting organization process for: {directory}\n")
    start_time = time.time()
    files_moved = 0

    # Create a reverse mapping from extension to folder name for quick lookups
    extension_to_folder = {}
    for folder_name, extensions in FILE_TYPE_MAPPINGS.items():
        for ext in extensions:
            extension_to_folder[ext.lower()] = folder_name

    # Iterate over all items in the target directory
    for item in directory.iterdir():
        # Skip directories and the script itself
        if not item.is_file() or item.name == __file__:
            continue

        file_extension = item.suffix.lower()

        # Determine the destination folder for the file
        # If the extension is not in our map, it goes to the "Other" folder.
        dest_folder_name = extension_to_folder.get(file_extension, "Other")
        dest_folder_path = directory / dest_folder_name

        # Create the destination folder if it doesn't exist
        try:
            dest_folder_path.mkdir(exist_ok=True)
        except OSError as e:
            print(f"Error creating directory {dest_folder_path}: {e}")
            continue # Skip to the next file if folder creation fails

        # Construct the full destination path for the file
        destination_file_path = dest_folder_path / item.name

        # Move the file to the new directory
        try:
            item.rename(destination_file_path)
            print(f"Moved: '{item.name}' -> {dest_folder_name}/")
            files_moved += 1
        except FileExistsError:
            print(f"Skipped (File Exists): '{item.name}' already in {dest_folder_name}/")
        except Exception as e:
            print(f"Error moving '{item.name}': {e}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    print("\n----------------------------------------")
    print("         Organization Complete!         ")
    print("----------------------------------------")
    print(f"Total files moved: {files_moved}")
    print(f"Time taken: {duration:.2f} seconds")


if __name__ == "__main__":
    # This block runs when the script is executed directly
    organize_files(TARGET_DIRECTORY)
